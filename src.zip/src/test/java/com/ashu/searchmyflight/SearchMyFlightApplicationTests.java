package com.ashu.searchmyflight;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SearchMyFlightApplicationTests {

	@Test
	void contextLoads() {
	}

}
